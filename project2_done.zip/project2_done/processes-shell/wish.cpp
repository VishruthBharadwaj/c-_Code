#include <iostream>
#include <vector>
#include <sstream>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

using namespace std;

vector<string> paths = {"/bin"};
const char error_message[] = "An error has occurred\n";

void print_error() {
    write(STDERR_FILENO, error_message, strlen(error_message));
}

vector<string> tokenize(const string &line, const string &delimiter) {
    vector<string> tokens;
    size_t start = 0, end;
    while ((end = line.find(delimiter, start)) != string::npos) {
        if (end != start)
            tokens.push_back(line.substr(start, end - start));
        start = end + delimiter.length();
    }
    if (start < line.size())
        tokens.push_back(line.substr(start));
    return tokens;
}

void execute_command(vector<string> &args, bool redirect, const string &outfile) {
    pid_t pid = fork();
    if (pid < 0) {
        print_error();
        return;
    }
    if (pid == 0) {
        if (redirect) {
            int fd = open(outfile.c_str(), O_WRONLY | O_CREAT | O_TRUNC, S_IRWXU);
            if (fd < 0) {
                print_error();
                exit(1);
            }
            dup2(fd, STDOUT_FILENO);
            dup2(fd, STDERR_FILENO);
            close(fd);
        }

        for (const string &path : paths) {
            string exec_path = path + "/" + args[0];
            vector<char *> c_args;
            for (auto &arg : args)
                c_args.push_back(&arg[0]);
            c_args.push_back(nullptr);

            execv(exec_path.c_str(), c_args.data());
        }
        print_error();
        exit(1);
    } else {
        wait(nullptr);
    }
}

void process_line(const string &line) {
    cout << "Processing line: \"" << line << "\"" << endl; // Debug print

    vector<string> tokens = tokenize(line, " ");
    cout << "Tokens: ";
    for (const string &token : tokens) {
        cout << "\"" << token << "\" ";
    }
    cout << endl;

    if (tokens.empty()) return;

    // Built-in commands
    if (tokens[0] == "exit") {
        if (tokens.size() != 1) {
            print_error();
        } else {
            exit(0);
        }
    } else if (tokens[0] == "cd") {
        if (tokens.size() != 2 || chdir(tokens[1].c_str()) != 0) {
            print_error();
        }
    } else if (tokens[0] == "path") {
        paths.clear();
        for (size_t i = 1; i < tokens.size(); ++i) {
            paths.push_back(tokens[i]);
        }
    } else {
        bool redirect = false;
        string outfile;

        for (size_t i = 0; i < tokens.size(); ++i) {
            if (tokens[i] == ">") {
                if (i + 1 < tokens.size() && !redirect) {
                    redirect = true;
                    outfile = tokens[i + 1];
                    tokens.erase(tokens.begin() + i, tokens.begin() + i + 2);
                } else {
                    print_error();
                    return;
                }
            }
        }
        execute_command(tokens, redirect, outfile);
    }
}

void interactive_mode() {
    string line;
    while (true) {
        cout << "wish> ";
        if (!getline(cin, line)) {
            exit(0);
        }
        line.erase(line.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace
        process_line(line);
    }
}

void batch_mode(const string &filename) {
    FILE *file = fopen(filename.c_str(), "r");
    if (!file) {
        print_error();
        exit(1);
    }

    char *line = nullptr;
    size_t len = 0;
    while (getline(&line, &len, file) != -1) {
        string trimmed_line(line);
        trimmed_line.erase(trimmed_line.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace
        process_line(trimmed_line);
    }
    free(line);
    fclose(file);
}

int main(int argc, char *argv[]) {
    if (argc == 1) {
        interactive_mode();
    } else if (argc == 2) {
        batch_mode(argv[1]);
    } else {
        print_error();
        return 1;
    }
    return 0;
}