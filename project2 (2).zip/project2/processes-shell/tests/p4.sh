#!/bin/bash
echo Linux
